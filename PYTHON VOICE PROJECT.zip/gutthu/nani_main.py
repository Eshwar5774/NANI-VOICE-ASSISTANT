import speech_recognition as sr
import pyttsx3
import webbrowser
import datetime
import random
import pywhatkit
import os
import wikipedia
import pyautogui
from dotenv import load_dotenv

# Load environment variables from .env file (still useful for other secrets later)
load_dotenv()

# Initialize recognizer and speaker
listener = sr.Recognizer()
nani = pyttsx3.init()

# Make NANI speak
def talk(text):
    print("NANI:", text)
    nani.say(text)
    nani.runAndWait()

# Listen once from mic
def take_command():
    listener = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        listener.adjust_for_ambient_noise(source)
        voice = listener.listen(source)
        try:
            command = listener.recognize_google(voice)
            return command.lower()
        except:
            return ""

# Jokes list
jokes = [
    "Why did the computer go to the doctor? Because it had a virus!",
    "I told my computer I needed a break, and it said: no problem, I’ll go to sleep.",
    "Why was the math book sad? Because it had too many problems.",
    "I would tell you a UDP joke, but you might not get it.",
    "What do you call a singing laptop? A Dell!"
]

# Greet
talk("Hi, I am NANI. How can I help you?")

# MAIN LOOP
while True:
    command = take_command()

    if "hello" in command:
        talk("Hi, how can I help you?")

    elif "your name" in command:
        talk("My name is NANI, your voice assistant.")

    elif "how are you" in command:
        talk("I'm doing great! Thanks for asking.")

    elif "open google" in command:
        talk("Opening Google")
        webbrowser.open("https://www.google.com")

    elif "search" in command:
        query = command.replace("search", "").strip()
        if query:
            talk(f"Searching for {query} on Google...")
            pywhatkit.search(query)
        else:
            talk("Please tell me what to search for.")

    elif "open youtube" in command:
        talk("Opening YouTube")
        webbrowser.open("https://www.youtube.com")

    elif "open gmail" in command:
        talk("Opening Gmail")
        webbrowser.open("https://mail.google.com")

    elif "wikipedia" in command:
        topic = command.replace("wikipedia", "").strip()
        if topic:
            talk(f"Searching Wikipedia for {topic}")
            try:
                summary = wikipedia.summary(topic, sentences=2)
                talk(summary)
            except Exception:
                talk("Sorry, I couldn't find anything on Wikipedia.")
        else:
            talk("Please tell me what to search on Wikipedia.")

    elif "open notepad" in command:
        talk("Opening Notepad")
        os.system("start notepad")

    elif "open chrome" in command:
        talk("Opening Chrome")
        os.system("start chrome")

    elif "time" in command:
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        talk(f"The current time is {current_time}")

    elif "screenshot" in command or "take screenshot" in command:
        talk("Taking screenshot...")
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"screenshot_{timestamp}.png"
        pyautogui.screenshot(filename)
        talk(f"Screenshot saved as {filename}")

    elif "date" in command:
        today = datetime.datetime.now().strftime("%B %d, %Y")
        talk(f"Today is {today}")

    elif "stop" in command or "exit" in command or "goodbye" in command:
        talk("Goodbye! See you later.")
        break
    elif "calculate" in command:
        try:
            expression = command.replace("calculate", "").strip()
            result = eval(expression)
            talk(f"The result is {result}")
        except:
            talk("Sorry, I couldn't calculate that.")

    elif "open calculator" in command:
        talk("Opening Calculator")
        os.system("calc")

    elif "joke" in command:
        joke = random.choice(jokes)
        talk(joke)

    elif "play" in command and "song" in command:
        song = command.replace("play", "").replace("song", "").strip()
        if song:
            talk(f"Playing {song} on YouTube")
            pywhatkit.playonyt(song)
            exit()
        else:
            talk("Please tell me the song name to play.")

    else:
        talk("I'm not sure how to respond to that.")

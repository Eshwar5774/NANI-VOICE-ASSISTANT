import speech_recognition as sr

recognizer = sr.Recognizer()

# Use default mic
with sr.Microphone() as source:
    print("NANI is listening...")
    recognizer.adjust_for_ambient_noise(source)
    audio = recognizer.listen(source)
    print("Got the audio... Recognizing...")

    try:
        command = recognizer.recognize_google(audio)
        print("You said:", command)
    except sr.UnknownValueError:
        print("Sorry, I didn’t understand that.")
    except sr.RequestError:
        print("Could not reach Google Speech service.")

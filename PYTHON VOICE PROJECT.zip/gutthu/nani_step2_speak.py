import pyttsx3

# Initialize the speech engine
nani = pyttsx3.init()

# Set voice properties
nani.setProperty('rate', 150)  # Speed of speech
voices = nani.getProperty('voices')
nani.setProperty('voice', voices[1].id)  # 0 = male, 1 = female

# Speak something
nani.say("Hello! I am NANI, your voice assistant.")
nani.runAndWait()
